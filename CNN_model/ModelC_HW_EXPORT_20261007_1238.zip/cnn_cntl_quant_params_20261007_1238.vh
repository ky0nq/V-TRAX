// Paste these values into top_cnn / top_cnn_cntl / cnn_cntl parameters.
parameter [31:0] L0_QM = 32'd2589547,
parameter [ 5:0] L0_QS = 6'd30,
parameter [31:0] L1_QM = 32'd8470202,
parameter [ 5:0] L1_QS = 6'd30,
parameter [31:0] L2_QM = 32'd6154952,
parameter [ 5:0] L2_QS = 6'd30,
// L3_QM/QS = Final ANGLE_MULT/ANGLE_SHIFT
parameter [31:0] L3_QM = 32'd3970754,
parameter [ 5:0] L3_QS = 6'd30
